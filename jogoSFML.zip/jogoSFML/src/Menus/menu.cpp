#include "menu.h"

Menu::Menu(): pJog(NULL){}
Menu::~Menu(){ pJog = NULL; }
void Menu::executar(){}
void Menu::save(){}
void Menu::load(){}
void Menu::score(){}