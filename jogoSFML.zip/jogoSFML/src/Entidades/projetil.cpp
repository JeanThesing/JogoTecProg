
#include "projetil.h"

Projeti::Projetil(): ativo(false){}
Projeti::~Projetil(){}
void Projeti::executar{}