#include "personagem.h"

Personagem::Personagem(): num_vidas(0){}
Personagem::~Personagem(){ num_vidas = -1; }
Personagem::salvarDataBuffer(){}
virtual void Personagem::mover(){}
