#include "jogador.h"

Jogador::Jogador(): pontos(0){ }
Jogador::~Jogador(){}
void Jogador::executar(){}