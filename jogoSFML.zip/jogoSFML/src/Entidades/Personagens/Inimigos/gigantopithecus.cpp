#include "gigantopithecus.h"

Gigantopithecus::Gigantopithecus(): forca(0){}
Gigantopithecus::~Gigantopithecus(){}
void Gigantopithecus::danificar(Jogador* p){}
void Gigantopithecus::executar(){}
short int Gigantopithecus::getForca(){ return forca; }
void Gigantopithecus::setForca(short int strenght){
    forca = strenght;
}
