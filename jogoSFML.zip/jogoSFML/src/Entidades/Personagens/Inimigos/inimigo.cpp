#include "inimigo.h"

Inimigo::Inimigo(): nivel_maldade(0){}
Inimigo::~Inimigo(){ nivel_maldade = -1; }
void Inimigo::salvarDataBuffer(){}