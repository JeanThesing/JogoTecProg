#include "include\Entidades\entidade.hpp"

CroMagnon::Entidades::Entidade::Entidade(): buffer(nullptr), velocidade(0.f, 0.f){}

CroMagnon::Entidades::Entidade::Entidade(sf::Drawable* figura): Ente(figura), 
buffer(nullptr), velocidade(0.f, 0.f){}  // construtor com figura

CroMagnon::Entidades::Entidade::~Entidade(){}

void CroMagnon::Entidades::Entidade::salvarDataBuffer(){ /*IMPLEMENTAR*/ }


 

           


