#include "fase1.h"

Fase1::Fase1(){}
Fase1::~Fase1(){}
void Fase1::criaInimMedios(){}
void Fase1::criaObstMedios(){}