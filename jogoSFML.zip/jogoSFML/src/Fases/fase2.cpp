#include "fase2.h"

Fase2::Fase2(){}
Fase2::~Fase2(){}
void Fase2::criaChefoes(){}
void Fase2::criaObstMedios(){}
void Fase2::criaObstDificil(){}
void Fase2::criaProjeteis(){}