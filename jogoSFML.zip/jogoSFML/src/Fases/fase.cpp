#include "fase.h"

Fase::Fase(){}
Fase::~Fase(){}
virtual void Fase::executar(){}
void Fase::gerenciador_colisoes(){}
void Fase::criaInimFaceis(){}
void Fase::criaPlataformas(){}
void Fase::criaCenario(){}