#include "stdafx.h"
#include "ente.hpp"

namespace CroMagnon{
    namespace Entidades{
        class Entidade: public Ente {

        protected:
            std::ostream* buffer;
            sf::Vector2f velocidade;

        public:
            Entidade();
            Entidade(sf::Drawable* figura);  // construtor com figura
            virtual ~Entidade();

            virtual void executar() = 0;
            virtual void mover(const sf::Vector2f& offset) = 0;

            virtual void salvar() = 0;      
            void salvarDataBuffer(); //Futuro uso
        };
    }
}



