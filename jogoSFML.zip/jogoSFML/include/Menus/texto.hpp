#include "..\stdafx.h"

#include "..\gerenciadores\ggraf.hpp"

namespace Menus{

    class Texto{

    private:
        std::string info;
        sf::Text texto
        static Gerenciadores::Ggraf* pGgraf;

    public:
        



    };
}