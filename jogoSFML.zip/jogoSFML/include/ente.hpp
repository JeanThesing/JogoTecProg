#include "stdafx.h"
#include "gergraf.hpp"

namespace CroMagnon{

    class Ente : public sf::Transformable {

    protected:
        static int nextId;
        int id;

        sf::Drawable* pFig;
    
    public:
        Ente(sf::Drawable* figura);
        Ente(); 
        virtual ~Ente();

        int getId() const;
        void desenhar(sf::RenderWindow& janela);

        virtual void executar() = 0;
    };
}